#!/usr/bin/env bash
set -euo pipefail

ROM_URL="${1:-}"
OUTPUT_DIR="${2:-rom_analysis_output}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ -z "$ROM_URL" ]]; then
  echo "Usage: $0 <ROM_URL-or-local-file> [output_directory]"
  exit 1
fi

command -v python3 >/dev/null || { echo "Python 3 is required."; exit 1; }
python3 -m py_compile "$SCRIPT_DIR/rom_analyzer.py"

echo "Beryl stock ROM analyzer"
echo "Input : $ROM_URL"
echo "Output: $OUTPUT_DIR"
echo
echo "The analyzer downloads/extracts the archive itself and parses vendor_boot."
echo "For vendor_boot ramdisk decompression, install the lz4 utility."
echo

if command -v lz4 >/dev/null; then
  echo "lz4: $(lz4 --version 2>&1 | head -1)"
else
  echo "WARNING: lz4 is not installed; vendor_boot ramdisk will be recorded but not decompressed."
fi

python3 "$SCRIPT_DIR/rom_analyzer.py" "$ROM_URL" "$OUTPUT_DIR"

echo
echo "Reports:"
echo "  $OUTPUT_DIR/analysis/ANALYSIS_REPORT.txt"
echo "  $OUTPUT_DIR/analysis/analysis_report.json"
echo "  $OUTPUT_DIR/analysis/DEVICE_TREE_CHECKLIST.txt"
echo "  $OUTPUT_DIR/device_tree_prep/EVIDENCE_MANIFEST.txt"
