# Beryl Stock ROM Analyzer — fixed toolkit

Target: POCO M7 Pro 5G (`beryl`), MT6855, Android 14 HyperOS 1.

## Files

- `rom_analyzer.py` — single source of truth for download/extraction/analysis.
- `stock_rom_analysis_workflow.yml` — GitHub Actions workflow that **runs `rom_analyzer.py` directly**.
- `quick_setup.sh` — local wrapper around the same Python analyzer.

## GitHub setup

Copy:

```text
rom_analyzer.py
.github/workflows/stock_rom_analysis_workflow.yml
```

The workflow expects the Python script at repository root.

For manual runs, use:

```text
Actions → Beryl Stock ROM Extract & Analyze → Run workflow
```

Enter the direct ROM URL. For scheduled runs, create an Actions repository variable named:

```text
STOCK_ROM_URL
```

## What the fixed analyzer does

It:

1. downloads the supplied ROM URL;
2. safely extracts ZIP/TAR.GZ/GZIP archives;
3. recursively inspects nested archives;
4. detects Android boot/vendor_boot images;
5. parses vendor_boot v3/v4 header fields;
6. extracts the vendor ramdisk section;
7. uses the host `lz4` utility to decompress Android LZ4 ramdisks;
8. parses `newc` CPIO using Python stdlib;
9. records fstab, recovery init, ueventd, module, DTB, SELinux and crypto-related evidence;
10. generates JSON/text reports and an evidence manifest.

It deliberately does **not** copy every stock `.ko`, `.so`, `.rc`, `.prop`, or image into the device tree.

## Important

The generated `device_tree_prep/` directory is evidence, not an instruction to blindly copy files into the tree. Integration decisions should be made from the actual Beryl stock recovery/vendor_boot contents.
